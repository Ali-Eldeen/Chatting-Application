import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.net.Socket;
import javax.sound.sampled.AudioFileFormat;
import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.swing.*;

public class ChatRoomClient extends JFrame {
    private static final int PORT = 12345;
    private Socket socket;
    private DataInputStream inputStream;
    private DataOutputStream outputStream;

    private static JTextArea textArea;
    public ChatRoomClient() {
        // Create GUI components
        textArea =new JTextArea();
        textArea.setEditable(false);
        JScrollPane scrollPane =new JScrollPane(textArea);
        scrollPane.setPreferredSize(new Dimension(300, 200));
        add(scrollPane,BorderLayout.CENTER);

        JTextField textField = new JTextField(30);
        JButton sendButton = new JButton("Send");
        JButton sendPhotoButton = new JButton("Send Photo");
        JButton sendAudioButton = new JButton("Send Audio");
        JPanel panel = new JPanel();

        // Add components to the panel
        panel.add(textField);
        panel.add(sendButton);
        panel.add(sendPhotoButton);
        panel.add(sendAudioButton);

        // Add panel to the frame
        add(panel, BorderLayout.SOUTH);

        // Set up event listeners
        sendButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                sendMessage(textField.getText());
                textField.setText("");
            }
        });

        sendPhotoButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                sendPhoto();
            }
        });

        sendAudioButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                sendAudio();
            }
        });

        // Set up the frame
        setTitle("Chat Room Client");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        pack();
        setVisible(true);

        // Connect to the server
        try {
            socket = new Socket("localhost", PORT);
            inputStream = new DataInputStream(socket.getInputStream());
            outputStream = new DataOutputStream(socket.getOutputStream());
            JOptionPane.showMessageDialog(null, "Connected to the server");
            receiveMessages();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Server disconnected");
            e.printStackTrace();
        }
    }

    private void sendMessage(String message) {
        try {
            outputStream.writeUTF("message");
            outputStream.writeUTF(message);
            showMessage("Client: "+message);
            outputStream.flush();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void sendPhoto() {
        showMessage("Sending a photo to the server...");
        JFileChooser fileChooser = new JFileChooser();
        int choice = fileChooser.showOpenDialog(this);

        if (choice == JFileChooser.APPROVE_OPTION) {
            File selectedFile = fileChooser.getSelectedFile();
            try {
                // Read the photo file as bytes
                FileInputStream fileInputStream = new FileInputStream(selectedFile);
                byte[] buffer = new byte[(int) selectedFile.length()];
                fileInputStream.read(buffer);
                fileInputStream.close();

                // Send the photo file to the server
                outputStream.writeUTF("photo");
                outputStream.writeInt(buffer.length);
                outputStream.write(buffer);
                outputStream.flush();
                showMessage("Photo sent successfully");
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    private void sendAudio() {
        showMessage("Sending an audio to the server...");
        JFileChooser fileChooser = new JFileChooser();
        int choice = fileChooser.showOpenDialog(this);

        if (choice == JFileChooser.APPROVE_OPTION) {
            File selectedFile = fileChooser.getSelectedFile();
            try {
                // Read the audio file
                AudioInputStream audioInputStream = AudioSystem.getAudioInputStream(selectedFile);
                AudioFormat format = audioInputStream.getFormat();

                // Convert audio file to byte array
                byte[] buffer = new byte[(int) (audioInputStream.getFrameLength() * format.getFrameSize())];
                audioInputStream.read(buffer);
                audioInputStream.close();

                // Send the audio file to the server
                outputStream.writeUTF("audio");
                outputStream.writeInt(buffer.length);
                outputStream.write(buffer);
                outputStream.flush();
                showMessage("Audio sent successfully");
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    private void receiveMessages() {
        Thread receiveThread = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    while (true) {
                        String messageType = inputStream.readUTF();
                        if (messageType.equals("message")) {
                            String message = inputStream.readUTF();
                            showMessage("Server: "+message);
                        } else if (messageType.equals("photo")) {
                            int fileSize = inputStream.readInt();
                            byte[] buffer = new byte[fileSize];
                            inputStream.readFully(buffer);
                            savePhoto(buffer);
                        } else if (messageType.equals("audio")) {
                            int fileSize = inputStream.readInt();
                            byte[] buffer = new byte[fileSize];
                            inputStream.readFully(buffer);
                            saveAudio(buffer);
                        }
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });
        receiveThread.start();
    }

    private void showMessage(String message) {
        textArea.append(message+'\n');
    }

    private void savePhoto(byte[] buffer) {
        showMessage("Server send a photo");
        JFileChooser fileChooser = new JFileChooser();
        int choice = fileChooser.showSaveDialog(this);

        if (choice == JFileChooser.APPROVE_OPTION) {
            File selectedFile = fileChooser.getSelectedFile();
            try {
                // Save the photo to the selected file
                FileOutputStream fileOutputStream = new FileOutputStream(selectedFile);
                BufferedOutputStream bufferedOutputStream = new BufferedOutputStream(fileOutputStream);
                bufferedOutputStream.write(buffer);
                File f = new File (selectedFile.getAbsolutePath());
                Desktop d = Desktop.getDesktop();
                d.open(f);
                bufferedOutputStream.flush();
                bufferedOutputStream.close();
                showMessage("Photo saved successfully!");

            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    private void saveAudio(byte[] buffer) {
        showMessage("Server send an audio");
        JFileChooser fileChooser = new JFileChooser();
        int choice = fileChooser.showSaveDialog(this);

        if (choice == JFileChooser.APPROVE_OPTION) {
            File selectedFile = fileChooser.getSelectedFile();
            try {
                // Save the audio to the selected file
                AudioInputStream audioInputStream = new AudioInputStream(
                        new ByteArrayInputStream(buffer),
                        new AudioFormat(AudioFormat.Encoding.PCM_SIGNED, 44100, 16, 2, 4, 44100, false),
                        buffer.length / 4
                );
                AudioSystem.write(audioInputStream, AudioFileFormat.Type.WAVE, selectedFile);
                File f = new File (selectedFile.getAbsolutePath());
                Desktop d = Desktop.getDesktop();
                d.open(f);
                showMessage("Audio saved successfully!");
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public static void main(String[] args) {
        new ChatRoomClient();
    }
}